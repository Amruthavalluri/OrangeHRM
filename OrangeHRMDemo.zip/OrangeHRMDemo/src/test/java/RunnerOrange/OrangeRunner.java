package RunnerOrange;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
	features="FeatureFile",
    glue="StepDefinitionOrange",
    plugin="com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
    dryRun=false,
    monochrome=true)
public class OrangeRunner extends AbstractTestNGCucumberTests{


}
