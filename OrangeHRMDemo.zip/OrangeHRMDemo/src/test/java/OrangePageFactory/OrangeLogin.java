package OrangePageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OrangeLogin {
WebDriver driver;
public OrangeLogin(WebDriver driver) {
	this.driver=driver;
	PageFactory.initElements(driver,this);
}
@FindBy(xpath="//input[@placeholder='Username']")
WebElement Username;
@FindBy(xpath="//input[@placeholder='Password']")
WebElement Password;
@FindBy(tagName="button")
WebElement login;
@FindBy(xpath="/html/body/div/div[1]/div[1]/aside/nav/div[2]/ul/li[1]/a")
WebElement Admin;

public void User(String username) {
	Username.sendKeys(username);
}
public void Pass(String password) {
	Password.sendKeys(password);
}
public void Login() {
	login.click();
}
public void admin() {
	Admin.click();
}
}
