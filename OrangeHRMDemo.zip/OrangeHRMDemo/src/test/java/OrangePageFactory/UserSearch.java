package OrangePageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class UserSearch {
	WebDriver driver;
	public UserSearch(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
@FindBy(xpath="/html/body/div/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[1]/div/div[2]/input")
WebElement Name;
@FindBy(xpath="/html/body/div/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[2]/div/div[2]/div/div/div[1]")
WebElement Userrole;
@FindBy(xpath="//input[@placeholder='Type for hints...']")
WebElement EmployeeName;
@FindBy(xpath="/html/body/div/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[4]/div/div[2]/div/div/div[1]")
WebElement Status;
@FindBy(xpath="//button[@type='submit']")
WebElement Search;

public void name(String nameuser) {
	Name.sendKeys(nameuser);
}
public void Role(String role) {
Select select = new Select(Userrole);
select.selectByVisibleText(role);
	//Userrole.sendKeys(role);
}
public void empname(String Employeename) {
	EmployeeName.sendKeys(Employeename);
}
public void Status(String status) {
Select select = new Select(Status);
select.selectByVisibleText(status);
	//Status.sendKeys(status);
}
public void search() {
	Search.click();
}
}
