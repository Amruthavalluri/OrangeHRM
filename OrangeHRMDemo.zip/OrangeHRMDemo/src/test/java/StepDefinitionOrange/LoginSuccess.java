package StepDefinitionOrange;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

//import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;



import OrangePageFactory.OrangeLogin;
import OrangePageFactory.UserSearch;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSuccess {

		WebDriver driver;
		@Before
		//public void setup() {
		public void before() {
			driver=new ChromeDriver();
			
	       driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		   driver.manage().window().maximize();
			
	         ChromeOptions option = new ChromeOptions();
			
			option.addArguments("--disable-popup-blocking");
			option.addArguments("--disable-notifications");
			
			
		}
//		@After
//		public void tearDown() {
//			if(driver!=null) {
//				driver.quit();
//			}
//		}
		
		@Given("The user should Navigate to Webpage")
		public void the_user_should_navigate_to_webpage() {
			driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
		   	}
		
		@When("The user enters {string}")
		public void the_user_enters(String username) {
			driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
			OrangeLogin o = new OrangeLogin(driver);
			o.User(username);
		}
		
		@When("user enters {string}")
		public void user_enters(String password) {  
			driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		    OrangeLogin o = new OrangeLogin(driver);
		    o.Pass(password);
		}

		@When("click on Login button")
		public void click_on_login_button() {
			driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
			OrangeLogin o = new OrangeLogin(driver);
			o.Login();
			//WebDriverWait wait = new WebDriverWait(driver, 10);
		   // wait.until(ExpectedConditions.urlContains("dashboard"));
		}
		public void Screenshot(String fileName) {
			driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
			TakesScreenshot screenshot=(TakesScreenshot)driver;
			File src = screenshot.getScreenshotAs(OutputType.FILE);
			String Filepath = "C:\\Users\\VALLUR\\Desktop\\Certificates"+fileName+".png";
			File dest=new File(Filepath);
			try {
				FileUtils.copyFile(src, dest);
				System.out.println("Screenshot captured:"+Filepath);
			}
			catch(IOException e) {
				System.out.println("Failed to capture screenshot:"+e.getMessage());
				e.printStackTrace();
			}
		}

		@Then("Login is successful")
		public void login_is_successful() {
			driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
//			WebDriverWait wait = new WebDriverWait(driver, 10);
//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[2]/button[2]")));
//			Screenshot("dashboard_after_login");
			//WebDriverWait wait = new WebDriverWait(driver, 10);
	       // wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[2]/button[2]")));
          Screenshot("dashboard_after_login");
		}
		
//			assertTrue(isLoggedIn(),"Login unsuccessful");
//			if(isLoggedIn()) {
//				driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/admin/viewSystemUsers");
//			}
//			else {
//				System.out.println("Login unsuccessful");
//			}
//		    
//		}
//		private boolean isLoggedIn() {
//			return driver.getCurrentUrl().contains("dashboard");
//		}
		
		
		@When("click on admin module")
		public void click_on_admin_module() {
			driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
			OrangeLogin o = new OrangeLogin(driver);
			o.admin();
		}

			@When("User is on Admin Page")
			public void user_is_on_admin_page() {
				driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
//				String currenturl = driver.getCurrentUrl();
//				String expectedurl ="https://opensource-demo.orangehrmlive.com/web/index.php/admin/viewSystemUsers";
//				Assert.assertEquals(currenturl,expectedurl,"User is not on admin page");
				//Screenshot("admin_page");
			}

			@When("Enter the username as {string}")
			public void enter_the_username_as(String username) {
				driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
			    UserSearch us = new UserSearch(driver);
			    us.name(username);
			}

			@When("Select user role")
			public void select_user_role(String role) {
				driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
				UserSearch us = new UserSearch(driver);
				us.Role(role);
			    
			}

			@When("Select EmployeeName as {string}")
			public void select_employee_name_as(String Employeename) {
				driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
				UserSearch us = new UserSearch(driver);
				us.empname(Employeename);
			}


			@When("Select status")
			public void select_status(String status) {
				driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
				UserSearch us = new UserSearch(driver);
				us.Status(status);
			}

			@When("click on search button")
			public void click_on_search_button() {
				driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
				UserSearch us = new UserSearch(driver);
				us.search();
			}

			@Then("Display message as search is successful")
			public void display_message_as_search_is_successful() {
				driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
			   //Screenshot("Search successful");
			}
			

//			@When("Enter the username from Excel")
//          	public void enter_the_username_from_excel() throws IOException{
//			Object[][] data = readExcelData("C:\\Users\\VALLUR\\Desktop\\testdata.xlsx","Sheet1");
//		String searchusername = (String) data[0][1];
//		String role=(String) data[0][2];
//	    String employeeName=(String) data[0][3];
//	    String status=(String) data[0][4];
//      	enter_the_username_as(searchusername);
//           select_user_role(role);
//           select_employee_name_as(employeeName);
//           select_status(status);
				
//		String username = (String) excelData[0][1];
//				UserSearch us = new UserSearch(driver);
//				us.name(username);
			    
//			}

//			@When("Select user role from Excel")
//			public void select_user_role_from_excel() throws IOException {
//				//Object[][] excelData = readExcelData("C:\\Users\\VALLUR\\Desktop\\testdata.xlsx","Sheet1");
////				String role = (String) excelData[0][2];
////				UserSearch us = new UserSearch(driver);
////				us.Role(role);
//			}

//			@When("Select EmployeeName from Excel")
//			public void select_employee_name_from_excel() throws IOException{
//				//Object[][] excelData = readExcelData("C:\\Users\\VALLUR\\Desktop\\testdata.xlsx","Sheet1");
////				String employeeName= (String) excelData[0][3];
////				UserSearch us = new UserSearch(driver);
////				us.empname(employeeName);
//			    
//			}

//			@When("Select status from Excel")
//			public void select_status_from_excel() throws IOException{
////				Object[][] excelData = readExcelData("C:\\Users\\VALLUR\\Desktop\\testdata.xlsx","Sheet1");
////				String status= (String) excelData[0][4];
////				UserSearch us = new UserSearch(driver);
////				us.Status(status);
//			}
			
		private Object[][] readExcelData(String excelPath, String sheetName) throws IOException {
		    FileInputStream fis = new FileInputStream(new File(excelPath));
	        XSSFWorkbook workbook = new XSSFWorkbook(fis);
	        XSSFSheet sheet = workbook.getSheet(sheetName);

	        int rowCount = sheet.getLastRowNum();
	        int colCount = sheet.getRow(0).getLastCellNum();
	        Object[][] data = new Object[rowCount][colCount];
		        for (int i = 0; i < rowCount; i++) {
		            Row row = sheet.getRow(i + 1); // Start from i+1 to skip header row
	            for (int j = 0; j < colCount; j++) {
	                Cell cell = row.getCell(j);
	                data[i][j] = cell.getStringCellValue();
		            }
		        }
		        workbook.close();
		        fis.close();

		        return data;
		    }
		
		@When("User should Enter the username")
		public void user_should_enter_the_username() {
		    
		}
		@When("User should Enter the password")
		public void user_should_enter_the_password() {
		    
		}
		
		@When("User is on Dashboard page")
		public void user_is_on_dashboard_page() {
		    
		}

		@When("Select user role as {string}")
		public void select_user_role_as(String string) {
		    
		}

		@When("Select status as {string}")
		public void select_status_as(String string) {
		    
		}

		@When("User should Enter the username as {string}")
		public void user_should_enter_the_username_as(String string) {
		    
		}

		@When("User should Enter the password as {string}")
		public void user_should_enter_the_password_as(String string) {
		    
		}


}

