package StepDefinitionOrange;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeMethod;

import OrangePageFactory.OrangeLogin;
import OrangePageFactory.UserSearch;

import org.testng.annotations.*;
public class EmployeeTest {
WebDriver driver;
@BeforeMethod
public void Login() {
	ChromeOptions options = new ChromeOptions();
	driver=new ChromeDriver(options);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	
}

 @DataProvider(name= "employeeData")
public Object[][] testData() throws IOException{
	 String excelPath = "C:\\Users\\VALLUR\\Desktop\\testdata.xlsx";
	 FileInputStream fis = new FileInputStream(new File(excelPath));
	 XSSFWorkbook workbook = new XSSFWorkbook(fis);
	 XSSFSheet sheet = workbook.getSheet("Sheet1");
	 
	 int rowCount =sheet.getLastRowNum();
	 int colCount = sheet.getRow(0).getLastCellNum();
	 Object[][]data = new Object[rowCount][colCount];
	 for(int i=0;i<rowCount;i++) {
		 Row row = sheet.getRow(i+1);
		 for(int j=0;j<colCount;j++) {
			 Cell cell = row.getCell(j);
			 data[i][j]=cell.getStringCellValue();
			 
		 }
	 }
	 workbook.close();
	 fis.close();
	 
	 return data;
	
}
 @Test(dataProvider = "employeeData")
 public void addEmployee(String name,String username,String password,String role) {
	 driver.get("https://opensource-demo.orangehrmlive.com/");
	 
	 OrangeLogin loginPage = new OrangeLogin(driver);
	 loginPage.User("Admin");
	 loginPage.Pass("admin123");
	 loginPage.Login();
	 loginPage.admin();
	 
	 UserSearch us = new UserSearch(driver);
	 us.name(username);
	 us.Role(role);
	 us.search();
 }
 @AfterMethod
 public void tearDown() {
	 if(driver !=null) {
		 driver.quit();
	 }
 }
}
